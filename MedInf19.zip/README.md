# Medizininformatik SoSe2019  

To run the program: gui6_arch_haupt.py
